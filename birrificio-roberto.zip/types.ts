export interface Beer {
  name: string;
  style: string;
  description: string;
}

export interface Testimonial {
  quote: string;
  author: string;
}

export interface SocialLink {
  name: string;
  href: string;
  icon: React.ReactNode;
}