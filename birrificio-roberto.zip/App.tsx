import React, { useState, useEffect } from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import Beers from './components/Beers';
import Story from './components/Story';
import Testimonials from './components/Testimonials';
import ECommerce from './components/ECommerce';
import VideoSection from './components/VideoSection';
import Contact from './components/Contact';
import Footer from './components/Footer';
import { BEERS_DATA } from './constants';

import { GoogleGenAI } from "@google/genai";

function App() {
  const [beerImages, setBeerImages] = useState<(string | null)[]>(new Array(BEERS_DATA.length).fill(null));
  const [isLoadingImages, setIsLoadingImages] = useState(true);
  const [imageError, setImageError] = useState<string | null>(null);

  const [videoFrames, setVideoFrames] = useState<string[]>([]);
  const [isLoadingVideo, setIsLoadingVideo] = useState(true);
  const [videoError, setVideoError] = useState<string | null>(null);


  useEffect(() => {
    const generateAllAssets = async () => {
        if (!process.env.API_KEY) {
            console.error("API key not found.");
            const errorMessage = "Impossibile connettersi ai servizi AI. Verranno usate immagini di riserva.";
            setImageError(errorMessage);
            setVideoError(errorMessage);
            setBeerImages([
                'https://picsum.photos/seed/claudio/600/800',
                'https://picsum.photos/seed/antonio/600/800',
                'https://picsum.photos/seed/nancy/600/800',
            ]);
             setVideoFrames(['https://picsum.photos/seed/bosa-video/1920/1080']);
            setIsLoadingImages(false);
            setIsLoadingVideo(false);
            return;
        }

        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

        // Generate Beer Images
        const generateBeerImages = async () => {
            setIsLoadingImages(true);
            setImageError(null);
            try {
                const prompts = [
                    "A professional product photograph of a rustic amber glass craft beer bottle. The label is made of textured, off-white paper and says 'CLAUDIO' in a bold, vintage serif font. Below the name, it says 'India Pale Ale'. The label design includes subtle illustrations of hops and grapefruit. The bottle is slightly dewy with condensation. The bottle is shown in full, standing on a plain, clean white background. Studio product lighting.",
                    "Professional product photography of a classic brown glass craft beer bottle. It has a cream-colored, artisanal paper label with the name 'ANTONIO' in a strong, elegant serif font. Below it, 'Birra Ambrata'. The label features a simple artistic sketch of a malt stalk. Full bottle shot. The bottle is presented against a clean, plain white background. The lighting is bright and even, typical of a professional product shot. Hyper-realistic.",
                    "Professional product shot of a sleek, light-colored glass craft beer bottle. The label is minimalist and modern, on a light blue-gray textured paper, with the name 'NANCY' in a clean, friendly sans-serif font. Subtext reads 'Birra Blanche'. The label has delicate, minimalist drawings of a coriander seed and an orange peel. The entire bottle is visible against a solid, clean white background. Crisp, even studio lighting. Photorealistic."
                ];
                const responses = await Promise.all(prompts.map(prompt =>
                    ai.models.generateImages({
                        model: 'imagen-3.0-generate-002',
                        prompt: prompt,
                        config: { numberOfImages: 1, outputMimeType: 'image/jpeg' },
                    })
                ));
                const generatedImages = responses.map(res => `data:image/jpeg;base64,${res.generatedImages[0].image.imageBytes}`);
                setBeerImages(generatedImages);
            } catch (err) {
                console.error("Error generating beer images:", err);
                setImageError("Non è stato possibile creare le etichette. Verranno usate delle immagini di riserva.");
                setBeerImages([
                    'https://picsum.photos/seed/claudio/600/800',
                    'https://picsum.photos/seed/antonio/600/800',
                    'https://picsum.photos/seed/nancy/600/800',
                ]);
            } finally {
                setIsLoadingImages(false);
            }
        };

        // Generate Video Frames
        const generateVideoFrames = async () => {
            setIsLoadingVideo(true);
            setVideoError(null);
            try {
                const prompts = [
                    "Golden hour, hyper-realistic photograph of the colorful houses along the Temo river in Bosa, Sardinia. The medieval castle is visible on the hill. The light is warm and inviting, reflecting on the water. Cinematic, breathtaking landscape.",
                    "Macro shot, shallow depth of field. A brewer's weathered hands cupping a handful of golden malted barley, with a few fresh hop cones scattered on a rustic wooden table beside them. Warm, natural light. Focus on texture and detail.",
                    "Interior shot of a craft microbrewery. A gleaming copper brew kettle with steam rising gently. A man in his 40s (Roberto), viewed from the side, watches the process with intense focus. The lighting is warm and atmospheric. Mood of passion and dedication.",
                    "A professional product shot of three distinct craft beer bottles (an IPA, an Amber ale, a Blanche) lined up on an old wooden barrel. The background is the warm, out-of-focus interior of the brewery. Dewy condensation on the bottles. Looks delicious and inviting.",
                    "Over-the-shoulder shot of a person holding a glass of amber-colored beer, looking out from a balcony over the town of Bosa at sunset. The focus is on the glass, but the beautiful, warm-toned town is softly blurred in the background. Conveys a sense of peace and satisfaction."
                ];
                 const responses = await Promise.all(prompts.map(prompt =>
                    ai.models.generateImages({
                        model: 'imagen-3.0-generate-002',
                        prompt: prompt,
                        config: { numberOfImages: 1, outputMimeType: 'image/jpeg', aspectRatio: '16:9' },
                    })
                ));
                const generatedFrames = responses.map(res => `data:image/jpeg;base64,${res.generatedImages[0].image.imageBytes}`);
                setVideoFrames(generatedFrames);
            } catch (err) {
                console.error("Error generating video frames:", err);
                setVideoError("Errore nel caricamento del video. Verrà mostrato un contenuto di riserva.");
                setVideoFrames(['https://picsum.photos/seed/bosa-fallback/1920/1080']);
            } finally {
                setIsLoadingVideo(false);
            }
        };

        generateBeerImages();
        generateVideoFrames();
    };

    generateAllAssets();
  }, []);


  const combinedError = imageError && imageError.startsWith("Impossibile connettersi") ? imageError : null;

  return (
    <div className="bg-brand-bg font-sans text-brand-text antialiased">
      <Header />
      <main>
        <Hero beerImages={beerImages} />
        {combinedError && <div className="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 container mx-auto -mt-12 mb-12" role="alert"><p>{combinedError}</p></div>}
        <Beers beerImages={beerImages} isLoading={isLoadingImages} error={imageError && !combinedError ? imageError : null} />
        <Story />
        <Testimonials />
        <ECommerce />
        <VideoSection frames={videoFrames} isLoading={isLoadingVideo} error={videoError} />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}

export default App;