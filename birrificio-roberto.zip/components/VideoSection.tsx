import React, { useState, useEffect } from 'react';

interface VideoSectionProps {
    frames: string[];
    isLoading: boolean;
    error: string | null;
}

const VideoSkeleton = () => (
    <div className="aspect-w-16 aspect-h-9 w-full bg-gray-200 rounded-lg shadow-2xl animate-pulse"></div>
);

const VideoSection = ({ frames, isLoading, error }: VideoSectionProps) => {
    const [currentFrame, setCurrentFrame] = useState(0);

    useEffect(() => {
        if (frames.length > 1) {
            const timer = setTimeout(() => {
                setCurrentFrame((prevFrame) => (prevFrame + 1) % frames.length);
            }, 5000); // Change image every 5 seconds
            return () => clearTimeout(timer);
        }
    }, [currentFrame, frames.length]);

    return (
        <section id="laboratorio" className="py-20 bg-white">
            <div className="container mx-auto px-6">
                <div className="text-center mb-12">
                    <h2 className="text-4xl font-serif font-bold text-brand-brown">La Magia della Produzione</h2>
                    <p className="text-lg text-brand-text mt-2">Un piccolo sguardo nel nostro laboratorio, dove nasce la magia.</p>
                </div>
                {error && <div className="bg-yellow-100 border-l-4 border-yellow-500 text-yellow-700 p-4 mb-8" role="alert"><p>{error}</p></div>}
                
                <div className="aspect-w-16 aspect-h-9 rounded-lg shadow-2xl overflow-hidden bg-black">
                    {isLoading ? (
                        <VideoSkeleton />
                    ) : (
                        <div className="relative w-full h-full">
                            {frames.map((frame, index) => (
                                <img
                                    key={index}
                                    src={frame}
                                    alt={`Scena della produzione ${index + 1}`}
                                    className={`absolute top-0 left-0 w-full h-full object-cover transition-opacity duration-1000 ease-in-out ${index === currentFrame ? 'opacity-100' : 'opacity-0'}`}
                                />
                            ))}
                        </div>
                    )}
                </div>
            </div>
        </section>
    );
};

export default VideoSection;