import React, { useState } from 'react';
import { SOCIAL_LINKS } from '../constants';

const Contact = () => {
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert(`Grazie, ${formData.name}! Il tuo messaggio è stato inviato.\n(Questa è una demo, nessun dato è stato realmente inviato).`);
    setFormData({ name: '', email: '', message: '' });
  };

  return (
    <section id="contatti" className="py-20 bg-brand-bg">
      <div className="container mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-serif font-bold text-brand-brown">Vieni a Trovarci</h2>
          <p className="text-lg text-brand-text mt-2">Siamo a Bosa, pronti a condividere una birra con te. Oppure scrivici!</p>
        </div>
        <div className="flex flex-col lg:flex-row gap-10">
          {/* Contact Form & Info */}
          <div className="lg:w-1/2 bg-white p-8 rounded-lg shadow-lg">
            <h3 className="text-2xl font-bold font-serif text-brand-brown mb-6">Manda un messaggio</h3>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-brand-text">Nome</label>
                <input type="text" id="name" name="name" value={formData.name} onChange={handleInputChange} required className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-brand-amber focus:border-brand-amber"/>
              </div>
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-brand-text">Email</label>
                <input type="email" id="email" name="email" value={formData.email} onChange={handleInputChange} required className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-brand-amber focus:border-brand-amber"/>
              </div>
              <div>
                <label htmlFor="message" className="block text-sm font-medium text-brand-text">Messaggio</label>
                <textarea id="message" name="message" rows={4} value={formData.message} onChange={handleInputChange} required className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-brand-amber focus:border-brand-amber"></textarea>
              </div>
              <div>
                <button type="submit" className="w-full bg-brand-amber text-white px-6 py-3 rounded-full text-lg font-semibold hover:bg-brand-bronze transition-colors duration-300 shadow-sm">
                  Invia Messaggio
                </button>
              </div>
            </form>
            <div className="mt-8 pt-6 border-t border-gray-200">
                <h4 className="font-semibold text-brand-brown mb-2">Indirizzo</h4>
                <p>Via della Malvasia, 123 <br/>08013 Bosa (OR), Sardegna</p>
                <h4 className="font-semibold text-brand-brown mt-4 mb-2">Seguici</h4>
                 <div className="flex space-x-4">
                  {SOCIAL_LINKS.map(link => (
                      <a key={link.name} href={link.href} className="text-brand-text hover:text-brand-amber transition-colors duration-300">
                          {link.icon}
                      </a>
                  ))}
              </div>
            </div>
          </div>
          {/* Map */}
          <div className="lg:w-1/2 h-80 lg:h-auto rounded-lg shadow-lg overflow-hidden">
             <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d12117.896791244715!2d8.48790384705973!3d40.29747514112185!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x12dcf57936171727%3A0x23956108f435080e!2sBosa%2C%20Province%20of%20Oristano%2C%20Italy!5e0!3m2!1sen!2sus!4v1684343831728!5m2!1sen!2sus"
              width="100%"
              height="100%"
              style={{ border: 0 }}
              allowFullScreen={true}
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            ></iframe>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;
