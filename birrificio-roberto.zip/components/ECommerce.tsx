import React, { useState } from 'react';

const ECommerce = () => {
  const [booking, setBooking] = useState({ name: '', email: '', guests: '2', date: '' });

  const handleBookingChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setBooking({ ...booking, [e.target.name]: e.target.value });
  };

  const handleBookingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert(`Grazie, ${booking.name}! La tua richiesta di prenotazione per ${booking.guests} persone per il giorno ${booking.date} è stata ricevuta. Ti contatteremo via email per la conferma.\n(Questa è una demo).`);
    setBooking({ name: '', email: '', guests: '2', date: '' });
  };

  const handleBuyClick = () => {
    alert('Grazie per il tuo interesse! La funzionalità di e-commerce sarà presto disponibile.\n(Questa è una demo).');
  };

  return (
    <section id="shop" className="py-20 bg-white">
      <div className="container mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-serif font-bold text-brand-brown">Acquista o Prenota</h2>
          <p className="text-lg text-brand-text mt-2 max-w-3xl mx-auto">Porta a casa il sapore di Bosa o vieni a trovarci per un'esperienza unica nel nostro birrificio.</p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-start">
          {/* Sezione Acquisto */}
          <div className="bg-brand-bg p-8 rounded-lg shadow-xl flex flex-col items-center text-center h-full">
            <h3 className="text-3xl font-serif text-brand-brown mb-4">Portaci a casa con te</h3>
            <p className="text-brand-text mb-6">Il modo migliore per scoprire le nostre creazioni.</p>
            <div className="bg-white p-6 rounded-lg shadow-md w-full max-w-sm">
                <h4 className="text-2xl font-bold font-serif text-brand-brown">Discovery Pack</h4>
                <p className="text-brand-text my-2">Una selezione delle nostre tre birre artigianali: Claudio, Antonio e Nancy.</p>
                <p className="text-3xl font-bold text-brand-amber my-4">€ 19.90</p>
                <button 
                    onClick={handleBuyClick}
                    className="w-full bg-brand-amber text-white px-6 py-3 rounded-full text-lg font-semibold hover:bg-brand-bronze transition-colors duration-300 shadow-sm"
                >
                    Acquista Ora
                </button>
            </div>
          </div>

          {/* Sezione Prenotazione Degustazione */}
          <div className="bg-brand-bg p-8 rounded-lg shadow-xl h-full">
            <h3 className="text-3xl font-serif text-brand-brown mb-6">Prenota una degustazione</h3>
            <form onSubmit={handleBookingSubmit} className="space-y-6">
               <div>
                <label htmlFor="name-booking" className="block text-sm font-medium text-brand-text">Nome</label>
                <input type="text" id="name-booking" name="name" value={booking.name} onChange={handleBookingChange} required className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-brand-amber focus:border-brand-amber"/>
              </div>
               <div>
                <label htmlFor="email-booking" className="block text-sm font-medium text-brand-text">Email</label>
                <input type="email" id="email-booking" name="email" value={booking.email} onChange={handleBookingChange} required className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-brand-amber focus:border-brand-amber"/>
              </div>
              <div className="flex gap-4">
                  <div className="flex-1">
                    <label htmlFor="guests" className="block text-sm font-medium text-brand-text">N. Persone</label>
                    <select id="guests" name="guests" value={booking.guests} onChange={handleBookingChange} required className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-brand-amber focus:border-brand-amber">
                        {[...Array(8)].map((_, i) => <option key={i+1} value={i+1}>{i+1}</option>)}
                    </select>
                  </div>
                  <div className="flex-1">
                    <label htmlFor="date" className="block text-sm font-medium text-brand-text">Data</label>
                    <input type="date" id="date" name="date" value={booking.date} onChange={handleBookingChange} required min={new Date().toISOString().split("T")[0]} className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-brand-amber focus:border-brand-amber"/>
                  </div>
              </div>
              <div>
                <button type="submit" className="w-full bg-brand-amber text-white px-6 py-3 rounded-full text-lg font-semibold hover:bg-brand-bronze transition-colors duration-300 shadow-sm">
                  Invia Richiesta
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ECommerce;
