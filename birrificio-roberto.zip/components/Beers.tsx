import React from 'react';
import { BEERS_DATA } from '../constants';
import { Beer } from '../types';

const BeerCardSkeleton = () => (
  <div className="bg-white rounded-lg shadow-lg overflow-hidden flex flex-col animate-pulse">
    <div className="h-80 bg-gray-200"></div>
    <div className="p-6 flex flex-col flex-grow">
      <div className="h-4 bg-amber-200 rounded w-1/4 mb-4"></div>
      <div className="h-6 bg-gray-300 rounded w-1/2 mb-3"></div>
      <div className="space-y-2 flex-grow">
        <div className="h-4 bg-gray-200 rounded"></div>
        <div className="h-4 bg-gray-200 rounded"></div>
        <div className="h-4 bg-gray-200 rounded w-5/6"></div>
      </div>
    </div>
  </div>
);


const BeerCard = ({ beer, imageUrl }: { beer: Beer, imageUrl: string }) => (
  <div className="bg-white rounded-lg shadow-lg overflow-hidden transform hover:-translate-y-2 transition-transform duration-300 flex flex-col">
    <div className="h-80 overflow-hidden bg-gray-100">
        <img src={imageUrl} alt={`Birra ${beer.name}`} className="w-full h-full object-cover" />
    </div>
    <div className="p-6 flex flex-col flex-grow">
      <span className="inline-block bg-amber-100 text-brand-amber text-xs font-semibold px-2 py-1 rounded-full uppercase tracking-wider self-start mb-3">
        {beer.style}
      </span>
      <h3 className="text-2xl font-serif font-bold text-brand-brown mb-2">{beer.name}</h3>
      <p className="text-brand-text flex-grow">{beer.description}</p>
    </div>
  </div>
);

interface BeersProps {
    beerImages: (string | null)[];
    isLoading: boolean;
    error: string | null;
}

const Beers = ({ beerImages, isLoading, error }: BeersProps) => {
  return (
    <section id="birre" className="py-20 bg-brand-bg">
      <div className="container mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-serif font-bold text-brand-brown">Le Nostre Birre</h2>
          <p className="text-lg text-brand-text mt-2 max-w-2xl mx-auto">Ogni birra è una storia, un carattere, un'emozione da scoprire.</p>
        </div>
        {error && <div className="bg-yellow-100 border-l-4 border-yellow-500 text-yellow-700 p-4 mb-8" role="alert"><p>{error}</p></div>}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-10">
          {isLoading ? (
            <>
              <BeerCardSkeleton />
              <BeerCardSkeleton />
              <BeerCardSkeleton />
            </>
          ) : (
            BEERS_DATA.map((beer, index) => (
              <BeerCard key={beer.name} beer={beer} imageUrl={beerImages[index]!} />
            ))
          )}
        </div>
      </div>
    </section>
  );
};

export default Beers;