import React, { useState, useEffect } from 'react';

const Header = () => {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header className={`sticky top-0 z-50 transition-all duration-300 ${isScrolled ? 'bg-brand-bg/80 shadow-md backdrop-blur-sm' : 'bg-transparent'}`}>
      <div className="container mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          <a href="#" className="text-2xl font-bold font-serif text-brand-brown tracking-wider">
            Roberto
          </a>
          <nav className="hidden md:flex items-center space-x-8">
            <a href="#birre" className="text-brand-text hover:text-brand-amber transition-colors duration-300">Le Nostre Birre</a>
            <a href="#storia" className="text-brand-text hover:text-brand-amber transition-colors duration-300">La Storia</a>
            <a href="#shop" className="text-brand-text hover:text-brand-amber transition-colors duration-300">Shop</a>
            <a href="#contatti" className="bg-brand-amber text-white px-4 py-2 rounded-full hover:bg-brand-bronze transition-colors duration-300 shadow-sm">Contatti</a>
          </nav>
          <div className="md:hidden">
            {/* Mobile menu button can be added here */}
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;