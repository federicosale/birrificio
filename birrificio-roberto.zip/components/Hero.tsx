import React from 'react';
import { BEERS_DATA } from '../constants';

interface HeroProps {
  beerImages: (string | null)[];
}

const Hero = ({ beerImages }: HeroProps) => {
  return (
    <section 
      id="home" 
      className="relative flex flex-col items-center justify-center min-h-[90vh] text-center text-white px-6 pt-24 pb-12 overflow-hidden"
    >
      <div 
        className="absolute inset-0 bg-cover bg-center bg-fixed z-0"
        style={{ backgroundImage: `url('https://picsum.photos/seed/bosa/1920/1080')` }}
      >
        <div className="absolute inset-0 bg-black/60"></div>
      </div>
      
      <div className="relative z-10 flex flex-col items-center">
        <h1 className="text-4xl md:text-6xl lg:text-7xl font-serif font-bold tracking-tight mb-4 text-shadow">
          Dal cuore di Bosa,
        </h1>
        <p className="text-4xl md:text-6xl lg:text-7xl font-serif font-bold tracking-tight text-amber-300 mb-8 text-shadow">
          birre fatte con passione.
        </p>
        
        <div className="relative w-full max-w-4xl h-64 md:h-80 lg:h-96 mt-8 flex justify-center items-end">
          {BEERS_DATA.map((beer, index) => (
            <div
              key={beer.name}
              className={`absolute transition-all duration-500 ease-out transform hover:scale-110 hover:z-20`}
              style={{
                width: 'clamp(100px, 20vw, 200px)',
                bottom: 0,
                transform: `translateX(${ (index - 1) * 80 }%) rotate(${ (index - 1) * 5 }deg)`
              }}
            >
              {beerImages[index] ? (
                <img
                  src={beerImages[index]!}
                  alt={`Bottiglia di birra ${beer.name}`}
                  className="object-contain w-full h-full drop-shadow-[0_10px_15px_rgba(0,0,0,0.4)]"
                />
              ) : (
                <div className="w-full h-full bg-gray-500/20 rounded-t-lg animate-pulse"></div>
              )}
            </div>
          ))}
        </div>
        
        <a 
          href="#birre"
          className="mt-24 inline-block bg-brand-amber text-white px-8 py-3 rounded-full text-lg font-semibold hover:bg-brand-bronze transition-transform duration-300 transform hover:scale-105 shadow-lg"
        >
          Scopri le nostre birre
        </a>
      </div>
    </section>
  );
};

export default Hero;