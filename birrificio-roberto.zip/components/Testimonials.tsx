import React from 'react';
import { TESTIMONIALS_DATA } from '../constants';

const Testimonials = () => {
  const QuoteIcon = () => (
    <svg className="w-12 h-12 text-amber-200" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 18 14">
        <path d="M6 0H2a2 2 0 0 0-2 2v4a2 2 0 0 0 2 2h4v1a3 3 0 0 1-3 3H2a1 1 0 0 0 0 2h1a5 5 0 0 0 5-5V2a2 2 0 0 0-2-2Zm10 0h-4a2 2 0 0 0-2 2v4a2 2 0 0 0 2 2h4v1a3 3 0 0 1-3 3h-1a1 1 0 0 0 0 2h1a5 5 0 0 0 5-5V2a2 2 0 0 0-2-2Z"/>
    </svg>
  );

  return (
    <section id="recensioni" className="py-20 bg-brand-bg">
      <div className="container mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-serif font-bold text-brand-brown">Dicono di noi</h2>
          <p className="text-lg text-brand-text mt-2">La soddisfazione dei nostri clienti è il nostro miglior ingrediente.</p>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {TESTIMONIALS_DATA.map((testimonial, index) => (
            <figure key={index} className="flex flex-col items-center justify-center p-8 text-center bg-white rounded-lg shadow-md">
              <blockquote className="max-w-md mx-auto mb-4 text-gray-600 lg:mb-8">
                <QuoteIcon />
                <p className="text-xl italic font-medium text-brand-text">"{testimonial.quote}"</p>
              </blockquote>
              <figcaption className="flex items-center justify-center space-x-3">
                <div className="font-semibold text-brand-brown">{testimonial.author}</div>
              </figcaption>
            </figure>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
