import React from 'react';

const Story = () => {
  return (
    <section id="storia" className="py-20 bg-white">
      <div className="container mx-auto px-6">
        <div className="flex flex-col lg:flex-row items-center gap-12">
          <div className="lg:w-1/2">
            <img 
              src="https://images.unsplash.com/photo-1566555163351-04a432753a93?q=80&w=1974&auto=format&fit=crop" 
              alt="Produzione artigianale della birra in un birrificio"
              className="rounded-lg shadow-2xl w-full h-full object-cover"
            />
          </div>
          <div className="lg:w-1/2">
            <h2 className="text-4xl font-serif font-bold text-brand-brown mb-4">La Nostra Storia</h2>
            <div className="space-y-4 text-lg text-brand-text">
              <p>
                Il Birrificio Roberto nasce da un sogno, quello del suo fondatore, Roberto, un bosano doc con una passione viscerale per la sua terra e per le cose buone e autentiche. Cresciuto tra i colori vivaci delle case lungo il Temo e i profumi della macchia mediterranea, Roberto ha sempre creduto che la Sardegna avesse un sapore unico da raccontare.
              </p>
              <p>
                Dopo anni passati a perfezionare le ricette nella cucina di casa, ha deciso di trasformare quella passione in un progetto di vita. Ha fondato il suo piccolo birrificio nel cuore di Bosa, un luogo dove la tradizione incontra l'innovazione, e dove ogni cotta è un omaggio al paesaggio, alla cultura e all'anima di questo angolo di paradiso.
              </p>
              <p>
                Le nostre birre non sono solo bevande, ma esperienze. Sono il frutto di una ricerca meticolosa delle migliori materie prime e di un processo produttivo che rispetta i tempi della natura, con la stessa pazienza e dedizione degli artigiani di un tempo.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Story;