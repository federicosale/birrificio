import React from 'react';
import { SOCIAL_LINKS } from '../constants';

const Footer = () => {
  return (
    <footer className="bg-brand-brown text-white">
      <div className="container mx-auto px-6 py-8">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <p className="text-center md:text-left text-sm text-amber-100">
            © {new Date().getFullYear()} Birrificio Roberto. Tutti i diritti riservati. <br/>
            Bevi responsabilmente.
          </p>
          <div className="flex space-x-4 mt-4 md:mt-0">
            {SOCIAL_LINKS.map(link => (
              <a key={link.name} href={link.href} aria-label={link.name} className="text-amber-100 hover:text-white transition-colors duration-300">
                {link.icon}
              </a>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
