import React from 'react';
import { Beer, Testimonial, SocialLink } from './types';

export const BEERS_DATA: Beer[] = [
  {
    name: 'Claudio',
    style: 'IPA',
    description: 'Una birra dal carattere deciso, con un’esplosione di profumi agrumati e tropicali. L’amaro intenso ma equilibrato la rende indimenticabile.',
  },
  {
    name: 'Antonio',
    style: 'Ambrata',
    description: 'Corposa e avvolgente, questa ambrata conquista con le sue note di caramello, malto tostato e un leggero sentore di frutta secca. Perfetta per ogni occasione.',
  },
  {
    name: 'Nancy',
    style: 'Blanche',
    description: 'Fresca, leggera e dissetante. I sentori di coriandolo e buccia d’arancia si fondono in un finale speziato che pulisce il palato e invita a un altro sorso.',
  },
];

export const TESTIMONIALS_DATA: Testimonial[] = [
  {
    quote: 'Una IPA sorprendente! L’equilibrio tra amaro e aroma è perfetto. Complimenti!',
    author: 'Marco L.',
  },
  {
    quote: 'Finalmente un sapore vero, artigianale. La Nancy è diventata la mia birra estiva preferita.',
    author: 'Giulia P.',
  },
  {
    quote: 'Il birrificio ha un’anima. Si sente nella birra e si vede nella passione che ci mettono. Antonio è superba.',
    author: 'Davide S.',
  },
];

const InstagramIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <rect width="20" height="20" x="2" y="2" rx="5" ry="5" />
        <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
        <line x1="17.5" y1="6.5" x2="17.51" y2="6.5" />
    </svg>
);

const FacebookIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z" />
    </svg>
);

export const SOCIAL_LINKS: SocialLink[] = [
  { name: 'Instagram', href: '#', icon: <InstagramIcon /> },
  { name: 'Facebook', href: '#', icon: <FacebookIcon /> },
];